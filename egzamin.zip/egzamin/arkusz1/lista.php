<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Lista przyjaciół</title>
    <link rel="stylesheet" href="styl.css">
  </head>
  <body>
    <header>
      <h1>Portal Społecznościowy - moje konto</h1>
    </header>
    <main>
      <h2>Moje zainteresowania</h2>
      <ul>
        <li>muzyka</li>
        <li>film</li>
        <li>komputery</li>
      </ul>
      <h2>Moi znajomi</h2>
      <?php
      $connect = new mysqli("localhost","root","","dane");
      $sql = "SELECT DISTINCT imie,nazwisko,opis,zdjecie from `osoby` where Hobby_id = 1 OR Hobby_id = 2 OR Hobby_id = 6;";
      $result = $connect->query($sql);
      while ($key = $result->fetch_assoc()) {
        echo <<< LABEL
        <section>
          <img src ="$key[zdjecie]" alt="przyjaciel" class = "zdjecie">
          <div class = "skryptdiv">
            <h3>$key[imie] $key[nazwisko]</h3>
            <p>Ostatni wpis: $key[opis]</p>
          </div>
        </section>
        <hr>
LABEL;
      }
       ?>
    </main>
    <footer>
      <div id = "first">
        Stronę wykonał: 6
      </div>
      <div id = "second">
        <a href="ja@portal.pl">napisz do mnie</a>
      </div>
    </footer>
  </body>
  <?php
    $connect -> close();
   ?>
</html>
