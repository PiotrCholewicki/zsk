<?php
  $connect = new mysqli("localhost","root","","ee09");
  $sql = "INSERT INTO `ratownicy` (nrKaretki,`ratownik1`, `ratownik2`, `ratownik3`) VALUES ('$_POST[karetkaNr]', '$_POST[ratownik1]','$_POST[ratownik2]','$_POST[ratownik3]')";
  $result = $connect->query($sql);
  echo "Do bazy zostało wysłane zapytanie $sql";
  $connect->close();
 ?>
