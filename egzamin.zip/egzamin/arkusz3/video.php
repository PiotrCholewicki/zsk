<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Video On Demand</title>
    <link rel="stylesheet" href="styl3.css">
  </head>
  <body>
    <header>
      <section id = "header1">
        <h1>Internetowa wypożyczalnia filmów</h1>
      </section>
      <section id = "header2">
        <table>
          <tr>
            <td>Kryminał</td>
            <td>Horror</td>
            <td>Przygodowy</td>
          </tr>
          <tr>
            <td>20</td>
            <td>30</td>
            <td>20</td>
          </tr>
        </table>
      </section>
    </header>
    <main>
      <section id = "list1">
        <h3>Polecamy</h3>
        <?php
        $connect = new mysqli("localhost","root","","dane3");
        $sql = "SELECT id,nazwa,opis,zdjecie FROM `produkty` where id IN(18,22,23,25);";
        $result = $connect->query($sql);
        echo "<section id = 'flex1'>";
        while ($key = $result->fetch_assoc()) {
          echo <<< LABEL
          <section class = "scr1">
          <h4>$key[id]. $key[nazwa]</h4>
          <img src = "$key[zdjecie]" alt = "film">
          <p>$key[opis]</p>
          </section>
LABEL;
        }
        echo "</section>";
         ?>
      </section>
      <section id = "list2">
        <h3>Filmy fantastyczne</h3>
        <?php
        $sql = "SELECT id,nazwa,opis,zdjecie from `produkty` where Rodzaje_id = 12;";
        $result = $connect->query($sql);
        echo "<section id = 'flex2'>";
        while ($key = $result->fetch_assoc()) {
          echo <<< LABEL
          <section class = "scr2">
          <h4>$key[id]. $key[nazwa]</h4>
          <img src = "$key[zdjecie]" alt = "film">
          <p>$key[opis]</p>
          </section>
LABEL;
        }
        echo "</section>";
         ?>
      </section>
    </main>
    <footer>
      <form method="post">
        Usuń film nr.:
        <input type="text" name ="idInsert">
        <input type="submit" value="Dodaj film">
      </form>
      <div id="footer2">
        Stronę wykonał: <a href=mailto:"ja@poczta.com">6</a>
      </div>
      <?php
      if(isset($_POST['idInsert'])){
        if (!empty($_POST['idInsert'])) {
          $connect = new mysqli("localhost","root","","dane3");
          $sql = "DELETE FROM `produkty` WHERE id = '$_POST[idInsert]' ";
          $result = $connect->query($sql);
          header("location: video.php");
        }
      }
      if(!isset($_COOKIE['cookie']))
      {
        setcookie("cookie",1,time()+5);
        echo "<p>Witaj, ustawiłem ciastka na 5 sekund</p>";
      }
      else{
        echo "<p>Ciastka juz istnieją</p>";
      }
       ?>
    </footer>
  </body>
</html>
<?php
  $connect -> close();
 ?>
