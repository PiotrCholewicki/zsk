<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Odloty samolotów</title>
    <link rel="stylesheet" href="styl6.css">
  </head>
  <body>
    <header>
      <section id = "headleft">
        <h2>Odloty z lotniska</h2>
      </section>
      <section id = "headright">
        <img src="zad6.png" alt="logotyp">
      </section>
    </header>
    <main>
      <h4>Tabela odlotów</h4>
      <table>
        <tr>
          <th>lp. </th>
          <th>numer rejsu </th>
          <th>czas </th>
          <th>kierunek </th>
          <th>status </th>
        </tr>
        <?php
        $connect = new mysqli("localhost","root","","egzamin");
        $sql = "SELECT id,nr_rejsu,czas,kierunek,status_lotu FROM `odloty` ORDER BY czas DESC;";
        $result = $connect->query($sql);
        while($key = $result->fetch_assoc()){
          echo <<< TABLE
          <tr>
          <td>$key[id]</td>
          <td>$key[nr_rejsu]</td>
          <td>$key[czas]</td>
          <td>$key[kierunek]</td>
          <td>$key[status_lotu]</td>
          </tr>
TABLE;
        }
         ?>
      </table>
    </main>
    <footer>
      <section id = "footleft">
        <a href="zad6.png" target="_blank">Pobierz obraz</a>
      </section>
      <section id = "footmid">
        <?php
        if(!isset($_COOKIE["cookieName"])){
          setcookie("cookieName",1,time()+5);
          echo "<p>Witaj na naszej stronie</p>";
        }
        else{
          echo "<p><u>Strona otwarta w zakresie trwania ciastek ;)</u></p>";
        }
         ?>
      </section>
      <section id = "footright">
        Autor: <a href="mailto: piotr.cholewicki@gmail.com">Wyślij mi maila</a>
      </section>
    </footer>
  </body>
</html>
<?php
  $connect -> close();
?>
