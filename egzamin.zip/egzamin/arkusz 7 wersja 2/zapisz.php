<?php
  $connect = new mysqli("localhost","root","","wedkowanie");
  $sql = "INSERT INTO `karty_wedkarskie`(`imie`, `nazwisko`, `adres`, `data_zezwolenia`,punkty) VALUES ('$_POST[imie]', '$_POST[nazwisko]','$_POST[adres]','$_POST[data]',NULL)";
  $result = $connect->query($sql);
  header("location: karta.html");
  $connect -> close();
 ?>
