<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Twój wskaźnik BMI</title>
    <link rel="stylesheet" href="styl4.css">
  </head>
  <body>
    <header>
      <section id = "headupper">
        <div id = "banner">
          <h2>Oblicz wskaźnik bmi</h2>
        </div>
        <div id = "logo">
          <img src="wzor.png" alt="liczymy BMI">
        </div>
      </section>
      <section id = "headlower">
        <div id ="left">
          <img src="rys1.png" alt="zrzuć kalorie!">
        </div>
        <div id = "right">
          <h1>Podaj dane</h1>
          <form method="post">
            Waga: <input type="number" name="weight"><br>
            Wzrost [cm]: <input type="number" name="height"><br>
            <input type="submit" value="Licz BMI i zapisz wynik"><br>
          </form>
          <?php
          $connect = new mysqli("localhost","root","","egzamin2");
          if(!empty($_POST['height'])&&!empty($_POST['weight'])){
              $height = ($_POST['height'])*($_POST['height']);
              $bmi = ($_POST['weight'])/($height)*10000;
              echo<<< BMI
              Twoja waga: $_POST[weight]kg Twój wzrost: $_POST[height]cm<br>BMI wynosi: $bmi
BMI;
              switch ($bmi) {
                case $bmi<19:
                  $todb = 1;
                  break;
                case $bmi>=19&&$bmi<26:
                  $todb = 2;
                    break;
                case $bmi>=26&&$bmi<31:
                  $todb = 3;
                    break;
                case $bmi>31:
                  $todb = 4;
              }
              $date = date('Y-m-d');
              $sql = "INSERT INTO `wynik` (`bmi_id`, `data_pomiaru`, `wynik`) VALUES ($todb, '$date', $bmi);";
              $result = $connect->query($sql);
            }
           ?>
        </div>
      </section>
    </header>
    <main>
      <table>
        <tr>
          <th>lp.</th>
          <th>Interpretacja</th>
          <th>zaczyna się od...</th>
        </tr>
        <?php
        $sql = "SELECT id,informacja,wart_min FROM bmi;";
        $result = $connect->query($sql);
        while ($key = $result->fetch_assoc()){
          echo<<<TABLE
          <tr>
            <td>$key[id]</td>
            <td>$key[informacja]</td>
            <td>$key[wart_min]</td>
          </tr>
TABLE;
        }
         ?>
      </table>
    </main>
    <footer>
      Autor: AAAAAA
      <a href="rys1.png">Rysunek 1</a>
      <?php
      if(!isset($_COOKIE['cookie'])){
        setcookie("cookie",1,time()+5);
        echo "<p id = 'red'>Witaj na naszej stronie</p>";
      }
      else{
        echo "<p id = 'blue'>Witaj ponownie</p>";
      }
       ?>
    </footer>
  </body>
</html>
<?php
  $connect -> close();
 ?>
